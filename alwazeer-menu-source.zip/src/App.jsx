import {useState,useEffect,useMemo,useRef} from 'react'
import {motion,AnimatePresence,useDragControls} from 'framer-motion'
import MENU from './menu.json'

const WA='201008023584',TEL='+201015333925',LIM=4
const DEV='https://www.facebook.com/mo.dm.97'
MENU.forEach(c=>c.items.forEach(it=>it.c=c))
const opts=it=>it.c.s?it.c.s.map((l,j)=>[l,it.p[j]]).filter(o=>o[1]!=null):[['',it.p[0]]]
const minP=it=>Math.min(...opts(it).map(o=>o[1]))
const lab=it=>it.c.t+(it.g?' - '+it.g:'')+' - '+it.n
const wa=t=>`https://wa.me/${WA}?text=${encodeURIComponent(t)}`
const IC={
  wa:'M16 3a13 13 0 0 0-11 19.8L3 29l6.4-2A13 13 0 1 0 16 3zm0 2.3a10.7 10.7 0 1 1-5.7 19.7l-.4-.2-3.8 1.2 1.2-3.7-.3-.4A10.7 10.7 0 0 1 16 5.3zm-4 5.3c-.3 0-.7.1-1 .5-.4.4-1.3 1.3-1.3 3.1s1.3 3.6 1.5 3.8c.2.3 2.6 4.1 6.4 5.6 3.1 1.2 3.8 1 4.5.9.7-.1 2.2-.9 2.5-1.8.3-.9.3-1.6.2-1.8-.1-.2-.4-.3-.8-.5s-2.2-1.1-2.5-1.2c-.3-.1-.6-.2-.8.2-.2.4-.9 1.2-1.1 1.4-.2.2-.4.3-.8.1-.4-.2-1.6-.6-3-1.9-1.1-1-1.9-2.3-2.1-2.7-.2-.4 0-.6.2-.8l.6-.7c.2-.2.2-.4.4-.6.1-.3.1-.5 0-.7l-1.1-2.7c-.3-.7-.6-.6-.8-.6z',
  ph:'M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z',
  fb:'M14 8h3V4h-3a4 4 0 0 0-4 4v2H7v4h3v8h4v-8h3l1-4h-4V8z',
  ig:'M7 3h10a4 4 0 0 1 4 4v10a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4zm0 2a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm5 2.5a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9zm0 2a2.5 2.5 0 1 0 0 5 2.5 2.5 0 0 0 0-5zM17.5 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z',
  cart:'M7 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm10 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM1 2v2h2l3.6 7.6-1.4 2.4A2 2 0 0 0 7 17h12v-2H7.400l1.100-2h7.500a2 2 0 0 0 1.700-1l3.600-6.500A1 1 0 0 0 20.400 4H5.200l-.9-2z',
  x:'M6 6l12 12M18 6L6 18',
  s:'M11 4a7 7 0 1 0 4.200 12.600l4.100 4.100 1.400-1.400-4.100-4.100A7 7 0 0 0 11 4zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10z'
}
const Ic=({n,s=20})=><svg width={s} height={s} viewBox={n=='wa'?'0 0 32 32':'0 0 24 24'} fill={n=='x'?'none':'currentColor'} stroke={n=='x'?'currentColor':'none'} strokeWidth="2" strokeLinecap="round"><path d={IC[n]}/></svg>

function Sheet({onClose,children}){
  const dc=useDragControls()
  useEffect(()=>{document.body.style.overflow='hidden';return()=>{document.body.style.overflow=''}},[])
  return <motion.div className="ov" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}>
    <motion.div className="sh" onClick={e=>e.stopPropagation()} initial={{y:'100%'}} animate={{y:0}} exit={{y:'100%'}}
      transition={{type:'spring',damping:32,stiffness:340}} drag="y" dragControls={dc} dragListener={false}
      dragConstraints={{top:0,bottom:0}} dragElastic={{top:0,bottom:.5}} onDragEnd={(_,i)=>i.offset.y>110&&onClose()}>
      <div className="grab" onPointerDown={e=>dc.start(e)}><i/></div>
      <button className="cls" onClick={onClose} aria-label="إغلاق"><Ic n="x" s={18}/></button>
      {children}
    </motion.div>
  </motion.div>
}

const Pic=({it,big})=><div className={'pic'+(big?' big':'')}><b>{it.e}</b><img src={`img/${it.i}.jpg`} alt="" loading="lazy" onError={e=>e.currentTarget.remove()}/></div>

function ItemSheet({it,onClose,onAdd}){
  const o=opts(it),[si,setSi]=useState(0),[q,setQ]=useState(1),[note,setNote]=useState('')
  const total=o[si][1]*q
  return <Sheet onClose={onClose}>
    <Pic it={it} big/>
    <div className="body">
      <small className="crumb">{it.c.t}{it.g?' › '+it.g:''}</small>
      <h3>{it.n}</h3>
      {o.length>1?<div className="seg">{o.map((x,j)=><button key={j} onClick={()=>setSi(j)} className={j==si?'on':''}>
        {j==si&&<motion.i layoutId="seg" className="pill" transition={{type:'spring',stiffness:420,damping:34}}/>}
        <span>{x[0]}</span><em>{x[1]} ج</em></button>)}</div>:<div className="one">{o[0][1]} <small>ج</small></div>}
      <input className="fld" value={note} onChange={e=>setNote(e.target.value)} placeholder="ملاحظات على الطلب (اختياري)"/>
      <div className="row">
        <div className="qty"><button onClick={()=>setQ(q+1)}>+</button><span>{q}</span><button onClick={()=>setQ(Math.max(1,q-1))}>−</button></div>
        <button className="btn pri grow" onClick={()=>onAdd({k:it.i+'|'+si+'|'+note.trim(),n:lab(it),s:o[si][0],p:o[si][1],q,t:note.trim()})}>أضف للسلة · {total} ج</button>
      </div>
      <div className="quick">
        <a className="btn wa beat" target="_blank" rel="noopener" href={wa(`مرحبًا الوزير 👋\nعايز أطلب: ${q}× ${lab(it)}${o[si][0]?' ('+o[si][0]+')':''} — ${total} ج${note.trim()?'\nملاحظة: '+note.trim():''}`)}><Ic n="wa"/>اطلب سريع واتساب</a>
        <a className="btn ghost beat d2" href={'tel:'+TEL}><Ic n="ph"/>اتصل</a>
      </div>
    </div>
  </Sheet>
}

function CartSheet({cart,setCart,onClose}){
  const [f,setF]=useState({n:'',p:'',a:'',x:''}),[err,setErr]=useState(false)
  const sum=cart.reduce((a,x)=>a+x.p*x.q,0)
  const chg=(i,d)=>{const c=cart.map((x,j)=>j==i?{...x,q:x.q+d}:x).filter(x=>x.q>0);setCart(c);if(!c.length)onClose()}
  const send=()=>{
    if(!f.n.trim()||!f.p.trim()||!f.a.trim()){setErr(true);return}
    const m=`🍕 *طلب جديد - الوزير*\n──────────\n`+cart.map(i=>`• ${i.q}× ${i.n}${i.s?' ('+i.s+')':''} — ${i.p*i.q} ج${i.t?'\n   ملاحظة: '+i.t:''}`).join('\n')+`\n──────────\n💰 *الإجمالي: ${sum} ج*\n👤 الاسم: ${f.n}\n📞 الموبايل: ${f.p}\n📍 العنوان: ${f.a}`+(f.x?`\n📝 ${f.x}`:'')
    window.open(wa(m),'_blank');setCart([]);onClose()
  }
  const set=k=>e=>setF({...f,[k]:e.target.value})
  return <Sheet onClose={onClose}><div className="body">
    <h3>سلة الطلب</h3>
    {cart.map((x,i)=><div className="line" key={x.k}><div><b>{x.n}{x.s?` (${x.s})`:''}</b><small>{x.p*x.q} ج{x.t?' · '+x.t:''}</small></div>
      <div className="qty sm"><button onClick={()=>chg(i,1)}>+</button><span>{x.q}</span><button onClick={()=>chg(i,-1)}>−</button></div></div>)}
    <div className="sum"><span>الإجمالي</span><b>{sum} ج</b></div>
    <input className={'fld'+(err&&!f.n.trim()?' bad':'')} placeholder="الاسم" value={f.n} onChange={set('n')} autoComplete="name"/>
    <input className={'fld'+(err&&!f.p.trim()?' bad':'')} placeholder="رقم الموبايل" type="tel" value={f.p} onChange={set('p')} autoComplete="tel"/>
    <textarea className={'fld'+(err&&!f.a.trim()?' bad':'')} rows="2" placeholder="العنوان بالتفصيل" value={f.a} onChange={set('a')}/>
    <input className="fld" placeholder="ملاحظات عامة (اختياري)" value={f.x} onChange={set('x')}/>
    <button className="btn wa full" onClick={send}><Ic n="wa"/>إرسال الطلب على واتساب</button>
  </div></Sheet>
}

function Card({it,i,onPick}){
  return <motion.button className="card" onClick={()=>onPick(it)} initial={{opacity:0,y:16}} whileInView={{opacity:1,y:0}} viewport={{once:true,margin:'0px 0px -40px 0px'}}
    transition={{duration:.4,delay:(i%2)*.06}} whileTap={{scale:.96}}>
    <Pic it={it}/><span className="add">+</span>
    <strong>{it.n}</strong>
    <em>{opts(it).length>1&&<small>من </small>}{minP(it)}<small> ج</small></em>
  </motion.button>
}

function Section({c,onPick}){
  const [open,setOpen]=useState(false),ref=useRef()
  const items=open?c.items:c.items.slice(0,LIM),more=c.items.length-LIM
  const nodes=[];let g=null
  items.forEach((it,i)=>{if(it.g!==g){g=it.g;if(g)nodes.push(<h4 key={'g'+g}>{g}</h4>)};nodes.push(<Card key={it.i} it={it} i={i} onPick={onPick}/>)})
  return <section id={c.id} ref={ref}>
    <h2><b>{c.e}</b>{c.t}<small>{c.items.length} صنف</small></h2>
    <motion.div layout className="grid">{nodes}</motion.div>
    {more>0&&<button className="more" onClick={()=>{setOpen(!open);if(open)ref.current.scrollIntoView({behavior:'smooth'})}}>
      {open?'عرض أقل':`عرض المزيد (${more})`}<motion.i animate={{rotate:open?180:0}}>⌄</motion.i></button>}
  </section>
}

export default function App(){
  const [cart,setCart]=useState(()=>{try{return JSON.parse(localStorage.wz2||'[]')}catch{return[]}})
  const [item,setItem]=useState(null),[cartOpen,setCartOpen]=useState(false),[q,setQ]=useState(''),[act,setAct]=useState(MENU[0].id)
  useEffect(()=>{try{localStorage.wz2=JSON.stringify(cart)}catch{}},[cart])
  useEffect(()=>{
    const io=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&setAct(e.target.id)),{rootMargin:'-25% 0px -70% 0px'})
    MENU.forEach(c=>{const el=document.getElementById(c.id);el&&io.observe(el)});return()=>io.disconnect()
  },[q])
  useEffect(()=>{const a=document.querySelector('.tabs .on');a&&a.parentElement.scrollTo({left:a.offsetLeft-a.parentElement.clientWidth/2+a.offsetWidth/2,behavior:'smooth'})},[act])
  const pick=it=>{navigator.vibrate?.(20);setItem(it)}
  const add=l=>{setCart(c=>{const f=c.find(x=>x.k==l.k);return f?c.map(x=>x.k==l.k?{...x,q:x.q+l.q}:x):[...c,l]});setItem(null)}
  const n=cart.reduce((a,x)=>a+x.q,0),sum=cart.reduce((a,x)=>a+x.p*x.q,0)
  const found=useMemo(()=>{const t=q.trim();return t?MENU.flatMap(c=>c.items).filter(it=>(it.n+' '+it.g+' '+it.c.t).includes(t)):null},[q])
  return <>
    <header className="hero">
      <img className="cover" src="cover.jpg" alt="الوزير بيتزا وفطائر"/>
      <div className="info">
                <div className="cta">
          <a className="btn wa" href={wa('مرحبًا الوزير 👋')} target="_blank" rel="noopener"><Ic n="wa"/>واتساب</a>
          <a className="btn ghost" href={'tel:'+TEL}><Ic n="ph"/>اتصال</a>
          <a className="sq" href="https://www.facebook.com/Pizza.elwazeer" target="_blank" rel="noopener" aria-label="فيسبوك"><Ic n="fb"/></a>
          <a className="sq" href="https://www.instagram.com/pizza_alwazeer/" target="_blank" rel="noopener" aria-label="انستجرام"><Ic n="ig"/></a>
        </div>
      </div>
    </header>
    <div className="stick">
      <label className="search"><Ic n="s" s={18}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="دوّر على صنف..."/>{q&&<button onClick={()=>setQ('')}><Ic n="x" s={16}/></button>}</label>
      {!q&&<nav className="tabs">{MENU.map(c=><a key={c.id} href={'#'+c.id} className={act==c.id?'on':''}>
        {act==c.id&&<motion.i layoutId="tab" className="pill" transition={{type:'spring',stiffness:420,damping:36}}/>}<span>{c.t}</span></a>)}</nav>}
    </div>
    <main>
      {found?(found.length?<div className="grid">{found.map((it,i)=><Card key={it.i} it={it} i={i} onPick={pick}/>)}</div>:<p className="empty">مفيش صنف بالاسم ده</p>)
        :MENU.map(c=><Section key={c.id} c={c} onPick={pick}/>)}
    </main>
    <footer>
      <img src="signature.png" alt="Mohamed.A Marketing"/>
      <a href={DEV} target="_blank" rel="noopener">تواصل مع مطوّر الموقع</a>
    </footer>
    <nav className="dock">
      <a className="call" href={'tel:'+TEL}><Ic n="ph"/><span>اتصال</span></a>
      <a className="wapp" href={wa('مرحبًا الوزير 👋')} target="_blank" rel="noopener"><Ic n="wa"/><span>واتساب</span></a>
      <AnimatePresence>{n>0&&<motion.button key="c" className="cartb" onClick={()=>setCartOpen(true)} initial={{width:0,opacity:0}} animate={{width:'auto',opacity:1}} exit={{width:0,opacity:0}}>
        <Ic n="cart"/><span>{n} · {sum} ج</span></motion.button>}</AnimatePresence>
    </nav>
    <AnimatePresence>{item&&<ItemSheet key={item.i} it={item} onClose={()=>setItem(null)} onAdd={add}/>}</AnimatePresence>
    <AnimatePresence>{cartOpen&&<CartSheet cart={cart} setCart={setCart} onClose={()=>setCartOpen(false)}/>}</AnimatePresence>
  </>
}
